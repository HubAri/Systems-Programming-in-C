bool prolog(int);
bool read_line(int, char*);
bool game(int, int);