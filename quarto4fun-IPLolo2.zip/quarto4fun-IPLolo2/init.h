bool get_args(int argc, char **argv);
bool check_argc(int argc);