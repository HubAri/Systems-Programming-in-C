void calculateMove();
int socketData;
int pipeData;