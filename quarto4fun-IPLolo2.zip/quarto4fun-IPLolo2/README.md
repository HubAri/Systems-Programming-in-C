# Quarto4fun

Systempraktikum WiSe 2021/22 - Gruppe 19 